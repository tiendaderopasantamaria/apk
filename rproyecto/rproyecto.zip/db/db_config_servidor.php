	$elUsr = "u397140890_cco30";
	$elPw  = "123456";
	$elServer ="mysql.hostinger.es";
	$laBd = "u397140890_ropa";

	$db_host = "mysql.hostinger.es";
	$db_name = "u397140890_ropa";
	$db_user = "u397140890_cco30";
	$db_pass = "123456";