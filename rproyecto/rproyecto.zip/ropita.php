<?php
session_start();

if(!isset($_SESSION['user_session']))
{
	header("Location: index.php");
}

include_once 'dbconfig.php';

$stmt = $db_con->prepare("SELECT * FROM usuarios WHERE id_usuarios=:uid");
$stmt->execute(array(":uid"=>$_SESSION['user_session']));
$row=$stmt->fetch(PDO::FETCH_ASSOC);

?>
				<?php
						include ("db/db.php");
						conectar_bd();
						$idr = $_GET['id'];
						$peticion= "SELECT * FROM tipo_filtro WHERE id_tipo_filtro = '$idr' ";

						$ejecutar= mysqli_query($conexio,$peticion);

						while($fila=mysqli_fetch_array($ejecutar)){			

							echo "									
								

								<div class='informacion'>
									
									<div class='cerrar'><div class='close-modal'><span class='icon-cross'></div></div>
									<div class='stocks'>Stock: ".$fila['stock']."</div>
									<div class='precios'>S/. ".$fila['precio_venta'].".00</div>
									
								</div>

								<script type='text/javascript'>
								$('.close-modal').on('click', function(){
									$('.contenedor-modal').removeClass('mostrar-modal');
									$('body').removeClass('scroll-oculto');
								})
							</script>
				 			";
					}
				?>
				

				<div class="oculto">
					<?php 
						
						conectar_bd();
						
						$peticion= "SELECT * FROM prenda WHERE id_tipo_filtro = '$idr'  ORDER BY id_prenda DESC  ";

						$ejecutar= mysqli_query($conexio,$peticion);

						while($fila=mysqli_fetch_array($ejecutar)){
							
							$img= base64_encode($fila['img']);
							$id_like_prenda= $fila['id_prenda'];						

							echo "									

								<div id='ropita'>
									
									
									<img id='prenda' src='data:image/jpeg;base64,$img''>
									<a id='ropalike' class='megustaropita$id_like_prenda' ><span class='icon-heart'></span></a>
									<div class='valor corazonropita$id_like_prenda'>".$fila['corazon']."</div>
									
								</div>
								
								<script type='text/javascript'>
									$(document).ready(function() {
									   $('.megustaropita$id_like_prenda').click(function(){
									      $.ajax({
										    type: 'GET',
										    url: 'procesolikeropita.php?id=$id_like_prenda',
										    success: function(a) {
									                $('.corazonropita$id_like_prenda').html(a);
									               
										    }
									       });
									   });
									});
								</script>
				 			";
					}
					?>	
				</div>

			<div class="iz">
				<?php 
				conectar_bd();

				$peticion= "SELECT * FROM prenda WHERE mod(id_prenda,2) = 0  and id_tipo_filtro = '$idr' ORDER BY id_prenda DESC ";

				$ejecutar= mysqli_query($conexio,$peticion);

						while($fila=mysqli_fetch_array($ejecutar)){
							
							$img= base64_encode($fila['img']);
							$id_like_prenda= $fila['id_prenda'];					

							echo "
									

								<div id='ropita'>
									
									
									<img id='prenda' src='data:image/jpeg;base64,$img''>
									<a id='ropalike' class='megustaropita$id_like_prenda' ><span class='icon-heart'></span></a>
									<div class='valor corazonropita$id_like_prenda'>".$fila['corazon']."</div>
									
								</div>


								
				 			";
					}

				
				?>
			</div>
				

				<div class="der">					
					<?php 
					conectar_bd();

					$peticion= "SELECT * FROM prenda WHERE  mod(id_prenda,2) <> 0 and id_tipo_filtro = '$idr'  ORDER BY id_prenda DESC ";

					$ejecutar= mysqli_query($conexio,$peticion);

					while($fila=mysqli_fetch_array($ejecutar)){
							
							$img= base64_encode($fila['img']);
							$id_like_prenda= $fila['id_prenda'];
							

							echo "
									

							<div id='ropita'>
									
									
									<img id='prenda' src='data:image/jpeg;base64,$img''>
									<a id='ropalike' class='megustaropita$id_like_prenda' ><span class='icon-heart'></span></a>
									<div class='valor corazonropita$id_like_prenda'>".$fila['corazon']."</div>
									
								</div>


								
				 			";
					}

				
					?>
				</div>

				