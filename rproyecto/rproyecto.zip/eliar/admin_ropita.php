<?php
session_start();

if(!isset($_SESSION['user_session']))
{
	header("Location: index.php");
}

include_once '../dbconfig.php';

$stmt = $db_con->prepare("SELECT * FROM usuarios WHERE id_usuarios=:uid");
$stmt->execute(array(":uid"=>$_SESSION['user_session']));
$row=$stmt->fetch(PDO::FETCH_ASSOC);

?>


				<?php
						include ("../db/db.php");
						conectar_bd();
						$idr = $_GET['id'];
						$peticion= "SELECT * FROM tipo_filtro WHERE id_tipo_filtro = '$idr' ";

						$ejecutar= mysqli_query($conexio,$peticion);

						while($fila=mysqli_fetch_array($ejecutar)){
							$id_feria= $fila['id_tipo_filtro'];
							$im= base64_encode($fila['img']);
							$id_filtro=$fila['id_feria'];	

							echo "

															
								

								<div class='informacion'>									
									<div class='cerrar'><div class='close-tiporopa'><span class='icon-cross'></div></div>
								</div>

								<div class='caja_feria cf$id_feria nueva_r$id_feria'>
									<img class='feria_img' src='data:image/jpeg;base64,$im'  />
									<div class='feria_a'>Agregar</div>
									<div class='feria_mes' >S/.".$fila['precio'].".00</div>
								</div>

								<br>	

								<script type='text/javascript'>
								$(document).ready(function() {
								   $('.close-tiporopa').click(function(){
								      $.ajax({
									    type: 'GET',
									    url: 'admin_filtro.php?id=$id_filtro',
									    success: function(a) {
								                
								                $('.cuerpo-modal').html(a);								                
									    }
								       });
								   });
								});
								</script>


								<script type='text/javascript'>
									$(document).ready(function() {
										$('.nueva_r$id_feria').click(function(){
											$.ajax({
												type: 'GET',
												url: 'admin_nueva_ropa.php?id=$id_feria',
												success: function(a) {								                
								       				$('.cuerpo-modal').html(a);								                
												}
											});
										});
									});
								</script>
				 			";
					}
				?>

				

				<div class="oculto">
					<?php 
						
						conectar_bd();
						$idt = $_GET['id'];				

						$peticion= "SELECT * FROM prenda WHERE id_tipo_filtro ='$idt'  ORDER BY id_prenda DESC  ";

						$ejecutar= mysqli_query($conexio,$peticion);
						while($fila=mysqli_fetch_array($ejecutar)){
							
							
							$img= base64_encode($fila['img']);	
							$id_like= $fila['id_tipo_filtro'];						

							echo "
									

								<div id='ropita'>									
									<div id='precio'>S/. ".$fila['precio'].".00</div>									
									<img id='prenda' src='data:image/jpeg;base64,$img'>
									
								</div>

								
								
									
				 			";
					}
					?>	
				</div>

			<div class="iz">
				<?php 
				conectar_bd();

				$peticion= "SELECT * FROM prenda WHERE mod(id_prenda,2) = 0  and id_tipo_filtro = '$idt' ORDER BY id_prenda DESC ";

			$ejecutar= mysqli_query($conexio,$peticion);
						while($fila=mysqli_fetch_array($ejecutar)){
							
							
							$img= base64_encode($fila['img']);
							$id_like= $fila['id_tipo_filtro'];						

							echo "
									
								<br>
								<div id='ropita'>
									<div id='precio'>S/. ".$fila['precio'].".00</div>
									<img id='prenda'src='data:image/jpeg;base64,$img'>
									<div class='valor'>".$fila['corazon']."</div>
									
								</div>
								
				 			";
					}

				
				?>
			</div>
				

				<div class="der">					
					<?php 
					conectar_bd();

					$peticion= "SELECT * FROM prenda WHERE mod(id_prenda,2) <> 0 and id_tipo_filtro='$idt' ORDER BY id_prenda DESC ";

					$ejecutar= mysqli_query($conexio,$peticion);

					while($fila=mysqli_fetch_array($ejecutar)){
							
							
							$img= base64_encode($fila['img']);
							$id_like= $fila['id_tipo_filtro'];							

							echo "
								<br>
								<div id='ropita'>
									<div id='precio'>S/. ".$fila['precio'].".00</div>
									<img id='prenda'src='data:image/jpeg;base64,$img'>
									<div class='valor'>".$fila['corazon']."</div>
									
								</div>
								
				 			";
					}

				
					?>
				</div>

				