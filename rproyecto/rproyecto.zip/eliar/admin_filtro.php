<?php
session_start();

if(!isset($_SESSION['user_session']))
{
	header("Location: index.php");
}

include_once '../dbconfig.php';

$stmt = $db_con->prepare("SELECT * FROM usuarios WHERE id_usuarios=:uid");
$stmt->execute(array(":uid"=>$_SESSION['user_session']));
$row=$stmt->fetch(PDO::FETCH_ASSOC);

?>
				<?php
						include ("../db/db.php");
						conectar_bd();
						$idr = $_GET['id'];
						$peticion= "SELECT * FROM feria WHERE id_feria = '$idr' ";

						$ejecutar= mysqli_query($conexio,$peticion);

						while($fila=mysqli_fetch_array($ejecutar)){
							$id_feria= $fila['id_feria'];
							$im= base64_encode($fila['img']);		

							echo "

															
								

								<div class='informacion'>
									
									<div class='cerrar'><div class='close-modal'><span class='icon-cross'></div></div>
									<div class='stocks'>Editar</div>
									
								</div>

								<div class='caja_feria cf$id_feria nuevo_t$id_feria'>
									<img class='feria_img' src='data:image/jpeg;base64,$im'  />
									<div class='feria_a'>".$fila['anio']."</div>
									<div class='feria_mes' >".$fila['mes']."</div>
								</div>		

								<script type='text/javascript'>
								$('.close-modal').on('click', function(){
									$('.contenedor-modal').removeClass('mostrar-modal');
									$('body').removeClass('scroll-oculto');
								})
								</script>

								<script type='text/javascript'>
									$(document).ready(function() {
									$('.nuevo_t$id_feria').click(function(){
										$.ajax({
										type: 'GET',
										url: 'admin_nuevo_tipo_de_ropa.php?id=$id_feria',
										success: function(a) {								                
								       		$('.cuerpo-modal').html(a);								                
										}
								});
						});
					});
				</script>
				 			";
					}
				?>

				

				<div class="oculto">
					<?php 
						
						conectar_bd();
						$idt = $_GET['id'];				

						$peticion= "SELECT * FROM tipo_filtro WHERE id_feria ='$idt'  ORDER BY id_tipo_filtro DESC  ";

						$ejecutar= mysqli_query($conexio,$peticion);
						while($fila=mysqli_fetch_array($ejecutar)){
							
							$tipo= $fila['tipo'];
							$img= base64_encode($fila['img']);	
							$id_like= $fila['id_tipo_filtro'];						

							echo "
									

								<div id='ropita' class='nueva_ropita$id_like'>
									<div id='tipo' class='$tipo'>".$fila['nombre']."</div>
									<div id='precio'>S/. ".$fila['precio'].".00</div>
									<div id='stock'>Stock: ".$fila['stock']."</div>
									<img id='prenda' src='data:image/jpeg;base64,$img'>
									<div id='caja'>
										<img src='img/corazon.png'>
										<h1 class='corazon$id_like'>".$fila['corazon']."</h1>
										<img src='img/carrito.png'>
										<h1>".$fila['compra']."</h1>
									</div>
								</div>	
							


							<script type='text/javascript'>
									$(document).ready(function() {
									   $('.nueva_ropita$id_like').click(function(){
									      $.ajax({
										    type: 'GET',
										    url: 'admin_ropita.php?id=$id_like',
										    success: function(a) {
									                $('.cuerpo-modal').html(a);
									               
										    }
									       });
									   });
									});
								</script>


							
				 			";
					}
					?>	
				</div>

			<div class="iz">
				<?php 
				conectar_bd();

				$peticion= "SELECT * FROM tipo_filtro WHERE mod(id_tipo_filtro,2) = 0  and id_feria = '$idt' ORDER BY id_tipo_filtro DESC ";

			$ejecutar= mysqli_query($conexio,$peticion);
						while($fila=mysqli_fetch_array($ejecutar)){
							
							$tipo= $fila['tipo'];
							$img= base64_encode($fila['img']);
							$id_like= $fila['id_tipo_filtro'];						

							echo "
									

								<div id='ropita' class='nueva_ropita$id_like'>
									<div id='tipo' class='$tipo'>".$fila['nombre']."</div>
									<div id='precio'>S/. ".$fila['precio'].".00</div>
									<div id='stock'>Stock: ".$fila['stock']."</div>
									
									<img id='prenda'src='data:image/jpeg;base64,$img'>
									<div id='caja'>
										<img src='img/corazon.png'>
										<h1 class='corazon$id_like'>".$fila['corazon']."</h1>
										<img src='img/carrito.png'>
										<h1>".$fila['compra']."</h1>
									</div>
								</div>
								
				 			";
					}

				
				?>
			</div>
				

				<div class="der">					
					<?php 
					conectar_bd();

					$peticion= "SELECT * FROM tipo_filtro WHERE  mod(id_tipo_filtro,2) <> 0 and id_feria = '$idt'  ORDER BY id_tipo_filtro DESC ";

					$ejecutar= mysqli_query($conexio,$peticion);

					while($fila=mysqli_fetch_array($ejecutar)){
							
							$tipo= $fila['tipo'];
							$img= base64_encode($fila['img']);
							$id_like= $fila['id_tipo_filtro'];							

							echo "
									

								<div id='ropita' class='nueva_ropita$id_like'>
									<div id='tipo' class='$tipo'>".$fila['nombre']."</div>
									<div id='precio'>S/. ".$fila['precio'].".00</div>
									<div id='stock'>Stock: ".$fila['stock']."</div>
									
									<img id='prenda' src='data:image/jpeg;base64,$img'>
									<div id='caja'>
										<img src='img/corazon.png'>
										<h1 class='corazon$id_like'>".$fila['corazon']."</h1>
										<img src='img/carrito.png'>
										<h1>".$fila['compra']."</h1>
									</div>
								</div>
								
				 			";
					}

				
					?>
				</div>

				