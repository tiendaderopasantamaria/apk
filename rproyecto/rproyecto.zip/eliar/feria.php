<div class="nueva_feria">
					<h1>Nueva Feria</h1>
				</div>
				<script type='text/javascript'>
								$('.nueva_feria').on('click', function(){
									$('.contenedor-modal').addClass('mostrar-modal');
									$('body').addClass('scroll-oculto');
								})
							</script>	

				<script type='text/javascript'>
					$(document).ready(function() {
						$('.nueva_feria').click(function(){
							$.ajax({
								type: 'GET',
								url: 'admin_nueva_feria.php',
									success: function(a) {								                
								        $('.cuerpo-modal').html(a);								                
									}
							});
						});
					});
				</script>
				<div class="feria">

				<?php
				include ("../db/db.php");
				conectar_bd();
				$peticion= "SELECT * FROM feria ORDER BY id_feria DESC " ;

				$ejecutar= mysqli_query($conexio,$peticion);
						while($fila=mysqli_fetch_array($ejecutar)){

							$id_feria= $fila['id_feria'];
							$im= base64_encode($fila['img']);
							echo "					

								<div class='caja_feria cf$id_feria'>
									<img class='feria_img' src='data:image/jpeg;base64,$im'  />
									<div class='feria_a'>".$fila['anio']."</div>
									<div class='feria_mes' >".$fila['mes']."</div>
								</div>

								<script type='text/javascript'>
									$('.cf$id_feria').on('click', function(){
										$('.contenedor-modal').addClass('mostrar-modal');
										$('body').addClass('scroll-oculto');
									})
								</script>	

								<script type='text/javascript'>
									$(document).ready(function() {
									   $('.cf$id_feria').click(function(){
									      $.ajax({
										    type: 'GET',
										    url: 'admin_filtro.php?id=$id_feria',
										    success: function(a) {
									                $('.cuerpo-modal').html(a);
									               
										    }
									       });
									   });
									});
								</script>
								";

						}
				?>


					
				</div>