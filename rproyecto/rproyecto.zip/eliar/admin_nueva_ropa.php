						<div class='informacion'>
									
							<div class='cerrar'><div class='close-tiporopa'><span class='icon-cross'></div></div>						
									
						</div>
							<script type='text/javascript'>
								$('.close-modal').on('click', function(){
									$('.contenedor-modal').removeClass('mostrar-modal');
									$('body').removeClass('scroll-oculto');
								})
							</script>

							<?php 
								$idr = $_GET['id'];

								echo "

								<script type='text/javascript'>
								$(document).ready(function() {
								   $('.close-tiporopa').click(function(){
								      $.ajax({
									    type: 'GET',
									    url: 'admin_ropita.php?id=$idr',
									    success: function(a) {
								                
								                $('.cuerpo-modal').html(a);								                
									    }
								       });
								   });
								});
								</script>
								";

							 ?>

							

				<div class="formulario"  id="registro-form">
      			  <form accept-charset="utf-8" method="POST" id="enviarimagenes" enctype="multipart/form-data" >
			        <h2>Nueva Ropita sii!</h2><hr/>
			        
			        <div id="error">
			        <!-- error will be shown here ! -->
			        </div>


			         <div class="grupo">
			        	<?php 
			        		include ("../db/db.php");
			        		
							conectar_bd();
							$idr = $_GET['id'];
							$peticion= "SELECT * FROM tipo_filtro WHERE id_tipo_filtro=$idr";

							$ejecutar= mysqli_query($conexio,$peticion);

							echo '
								<select class="form-control" type="text" name="idfiltro" required>
								';
							while($fila=mysqli_fetch_array($ejecutar)){
							echo'				        		 
				        		<option value="'.$fila['id_tipo_filtro'].' " selected>'.$fila['nombre'].'</option>
								';
								}
							echo'</select>';

			        	 ?>
				        
			        </div>

			        <div class="grupo">
			        	<?php 
			        		
							conectar_bd();
							$idr = $_GET['id'];
							$peticion= "SELECT * FROM tipo_filtro WHERE id_tipo_filtro=$idr";

							$ejecutar= mysqli_query($conexio,$peticion);

							echo '
								<select class="form-control" type="text" name="precio" required>
								';
							while($fila=mysqli_fetch_array($ejecutar)){
							echo'				        		 
				        		<option value="'.$fila['precio_venta'].' " selected>'.$fila['precio_venta'].'</option>
								';
								}
							echo'</select>';

			        	 ?>
				        
			        </div>

			        <div class="grupo">
			        	<label for="talla">Talla:</label>
				        <input type="text" class="form-control" placeholder="Talla" name="talla" id="talla" required/>
			        </div>

			        <div class="grupo">
			        	<label for="img">Img:</label>
				        <input type="file" name="imagen"/>
			        </div>
			       
			     	<hr />

			         <div class="grupo">
			            <input type="submit"  value="Enviar"  name="enviar" id="enviar" />

			    	 </div>
			      </form>
			     </div>


				<script>
					$("#enviarimagenes").on("submit", function(e){
						e.preventDefault();
						var formData = new FormData(document.getElementById("enviarimagenes"));
					
						$.ajax({
							url: "registro_ropa.php",
							type: "POST",
							dataType: "HTML",
							data: formData,
							cache: false,
							contentType: false,
							processData: false
						}).done(function(echo){
							$("#error").html(echo);
						});
					});
				</script>
				