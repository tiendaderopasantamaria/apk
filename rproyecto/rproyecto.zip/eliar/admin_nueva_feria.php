						<div class='informacion'>
									
							<div class='cerrar'><div class='close-modal'><span class='icon-cross'></div></div>						
									
						</div>
							<script type='text/javascript'>
								$('.close-modal').on('click', function(){
									$('.contenedor-modal').removeClass('mostrar-modal');
									$('body').removeClass('scroll-oculto');
								})
							</script>

							<script type='text/javascript'>
								$(document).ready(function() {
								   $('.close-modal').click(function(){
								      $.ajax({
									    type: 'GET',
									    url: 'feria.php',
									    success: function(a) {
								                
								                $('#principal').html(a);								                
									    }
								       });
								   });
								});
							</script>

				<div class="formulario"  id="registro-form">
      			  <form accept-charset="utf-8" method="POST" id="enviarimagenes" enctype="multipart/form-data" >
			        <h2>Nueva Feria</h2><hr/>
			        
			        <div id="error">
			        <!-- error will be shown here ! -->
			        </div>

			        <div class="grupo">
			        	<label for="anio">Año:</label>
				        <input type="text" class="form-control" placeholder="Año" name="anio" id="anio" required/>
			        </div>

			        <div class="grupo">
			        	<label for="mes">Mes:</label>
				        <input type="text" class="form-control" placeholder="Mes" name="mes" id="mes" required/>
			        </div>

			        <div class="grupo">
			        	<label for="img">Img:</label>
				        <input type="file" name="imagen"/>
			        </div>
			       
			     	<hr />

			         <div class="grupo">
			            <input type="submit"  value="Enviar"  name="enviar" id="enviar" />

			    	 </div>
			      </form>
			     </div>


				<script>
					$("#enviarimagenes").on("submit", function(e){
						e.preventDefault();
						var formData = new FormData(document.getElementById("enviarimagenes"));
					
						$.ajax({
							url: "registro_feria.php",
							type: "POST",
							dataType: "HTML",
							data: formData,
							cache: false,
							contentType: false,
							processData: false
						}).done(function(echo){
							$("#error").html(echo);
						});
					});
				</script>
				