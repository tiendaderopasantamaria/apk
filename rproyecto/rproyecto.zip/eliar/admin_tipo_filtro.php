<?php
session_start();

if(!isset($_SESSION['user_session']))
{
	header("Location: index.php");
}

include_once '../dbconfig.php';

$stmt = $db_con->prepare("SELECT * FROM usuarios WHERE id_usuarios=:uid");
$stmt->execute(array(":uid"=>$_SESSION['user_session']));
$row=$stmt->fetch(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html>
<head>
	<title>SM</title>
	<link rel="icon" type="image/png" href="../img/maria.png" />
	<!-- JS -->
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/main.js"></script>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"  />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel=stylesheet href="../css/main.css" type="text/css" />
	<link rel=stylesheet href="../css/ico.css" type="text/css" />
	<link rel=stylesheet href="../css/main_modal_filtro.css" type="text/css" />
	<link rel=stylesheet href="../css/admin_css.css" type="text/css" />
	<link rel=stylesheet href="../css/main_usuario.css" type="text/css" />
	
	
	

</head>
<div class="fondo"></div>
<body >

	<div class="body">
		<div class="contenedor-modal">
			
			<div class="cuerpo-modal" >
					
			</div>

		</div>
	</div>
		
	</div>

	<section id='banner'>
		
	</section>

	<section id='body'></section>
	<div id="contenedor" class="contenedor">
		<nav>

			<div class="filtro fil">
				<div class="titulo">Filtro</div>

				<div class="tipo">
					<?php 
					
					include ("../db/db.php");
					conectar_bd();

					$peticion= "SELECT * FROM filtro ORDER BY id_filtro DESC ";

					$ejecutar= mysqli_query($conexio,$peticion);


					while($fila=mysqli_fetch_array($ejecutar)){
						$filtro= $fila['id_filtro'];
						$nombre= $fila['nombre'];

						echo "				

							<a id='filtro$filtro'>$nombre</a>

							<script type='text/javascript'>
								$(document).ready(function() {
								   $('#filtro$filtro').click(function(){
								      $.ajax({
									    type: 'GET',
									    url: 'indexfiltromostrar.php?id=t$filtro',
									    success: function(a) {
								                $('#principal').html(a);
								               
									    }
								       });
								   });
								});
							</script>
							
			 			";
					}
					?>

					
					<a id='tipo1'>Todo</a>
							<script type='text/javascript'>
								$(document).ready(function() {
								   $('#tipo1').click(function(){
								      $.ajax({
									    type: 'GET',
									    url: 'indexfiltrotodo.php',
									    success: function(a) {
								                
								                $('#principal').html(a);								                
									    }
								       });
								   });
								});
							</script>
							
				</div>
			</div>

			<div>				
				<img src="img/user.jpg">
				<div class="caja">
					<a id="ves" ><span class="icon-heart"></span></a>
					<a id="pan" class="pan" href="#"><span class="icon-phone"></span></a>
					<a id="ofe" href="logout.php"><span class="icon-cross"></span></a>
					<a id="len" href="#"><span class="icon-user"></span></a>
					<a id="pol" class="pol" href="#"><span class="icon-heart"></span></a>					
				</div>
				<script type='text/javascript'>
					$(document).ready(function() {
						$('#ves').click(function(){
							$.ajax({
								type: 'GET',
								url: 'filtrocorazon.php?id=si',
									success: function(a) {								                
								        $('#principal').html(a);								                
									}
							});
						});
					});
				</script>

				<script type='text/javascript'>
								$('.pol').on('click', function(){
									$('.contenedor-modal').addClass('mostrar-modal');
									$('body').addClass('scroll-oculto');
								})
							</script>	

				<script type='text/javascript'>
					$(document).ready(function() {
						$('.pol').click(function(){
							$.ajax({
								type: 'GET',
								url: 'filtrocorazonropita.php?id=si',
									success: function(a) {								                
								        $('.cuerpo-modal').html(a);								                
									}
							});
						});
					});
				</script>

				<script type='text/javascript'>
								$('.pan').on('click', function(){
									$('.contenedor-modal').addClass('mostrar-modal');
									$('body').addClass('scroll-oculto');
								})
							</script>	

				<script type='text/javascript'>
					$(document).ready(function() {
						$('.pan').click(function(){
							$.ajax({
								type: 'GET',
								url: 'social.php',
									success: function(a) {								                
								        $('.cuerpo-modal').html(a);								                
									}
							});
						});
					});
				</script>
				
			</div>

			<div class="filtro2 fil">
				<div class="titulo">Otros</div>

				<div class="tipo">
				<a id="tipo1" href="">Más Vendido</a>
				<a id="tipo2" href="">Votos</a>
				<a id="tipo3" href="">Nuevo</a>
				<a id="tipo4" href="">Conjunto</a>
				<a id="tipo5" href="">Diseño Katy</a>
				</div>
			</div>
		</nav>

		

		<div id="cuerpo" class="cuerpo">
			
			
			<br>
			<br>
			<br>
			<br>
			<br>
			<div id="principal">
					
				<div class="nueva_feria">
					<h1>Nueva Feria</h1>
				</div>
				<script type='text/javascript'>
								$('.nueva_feria').on('click', function(){
									$('.contenedor-modal').addClass('mostrar-modal');
									$('body').addClass('scroll-oculto');
								})
							</script>	

				<script type='text/javascript'>
					$(document).ready(function() {
						$('.nueva_feria').click(function(){
							$.ajax({
								type: 'GET',
								url: 'admin_nueva_feria.php',
									success: function(a) {								                
								        $('.cuerpo-modal').html(a);								                
									}
							});
						});
					});
				</script>
				<div class="feria">

				<?php

				conectar_bd();
				$peticion= "SELECT * FROM feria ORDER BY id_feria DESC " ;

				$ejecutar= mysqli_query($conexio,$peticion);
						while($fila=mysqli_fetch_array($ejecutar)){

							$id_feria= $fila['id_feria'];
							$im= base64_encode($fila['img']);
							echo "					

								<div class='caja_feria cf$id_feria'>
									<img class='feria_img' src='data:image/jpeg;base64,$im'  />
									<div class='feria_a'>".$fila['anio']."</div>
									<div class='feria_mes' >".$fila['mes']."</div>
								</div>

								<script type='text/javascript'>
									$('.cf$id_feria').on('click', function(){
										$('.contenedor-modal').addClass('mostrar-modal');
										$('body').addClass('scroll-oculto');
									})
								</script>	

								<script type='text/javascript'>
									$(document).ready(function() {
									   $('.cf$id_feria').click(function(){
									      $.ajax({
										    type: 'GET',
										    url: 'admin_filtro.php?id=$id_feria',
										    success: function(a) {
									                $('.cuerpo-modal').html(a);
									               
										    }
									       });
									   });
									});
								</script>
								";

						}
				?>


					
				</div>


			
		</div>

		</div>



</body>

</html>
