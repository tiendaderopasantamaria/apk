<?php
session_start();

if(!isset($_SESSION['user_session']))
{
	header("Location: index.php");
}

include_once 'dbconfig.php';

$stmt = $db_con->prepare("SELECT * FROM usuarios WHERE id_usuarios=:uid");
$stmt->execute(array(":uid"=>$_SESSION['user_session']));
$row=$stmt->fetch(PDO::FETCH_ASSOC);

?>
							
								

	<div class='informacion'>									
		<div class='cerrar'><div class='close-modal'><span class='icon-cross'></div></div>							
	</div>



	<div class="social">
		<a class="ims" href=""><img src="img/f.png"></a>
		<a class="ims" href=""><img src="img/w.png"></a>
	</div>

	<div class="gia">
		<div class="info">
			Déjenos el nombre de usuario y un número celular por en el inbox de cualquiera de nuestras redes sociales.
			<br><br>
			Gracias por confiar en nuestra empresa.
		</div>
	</div>

	<script type='text/javascript'>
		$('.close-modal').on('click', function(){
			$('.contenedor-modal').removeClass('mostrar-modal');
			$('body').removeClass('scroll-oculto');
		})
	</script>

